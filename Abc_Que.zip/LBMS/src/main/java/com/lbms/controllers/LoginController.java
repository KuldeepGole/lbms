package com.lbms.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lbms.models.Login;
import com.lbms.models.LoginUsersMaster;
import com.lbms.services.LoginService;

@SuppressWarnings("unused")
@Controller
public class LoginController {
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	private LoginService loginService;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView showLoginPage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mod = new ModelAndView("login");
		mod.addObject("login", new Login());
		return mod;
	}

	// LoginProcess action name of login page
	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("login") Login login, HttpSession session) {
		ModelAndView mav = null;
		session.setAttribute("userName", login.getLoginName());
		LoginUsersMaster loginUsersMaster = loginService.validateLogin(login);

		// System.out.println(session.getAttribute("userName").toString());

		if (null != loginUsersMaster) {
			mav = new ModelAndView("librarian");
			mav.addObject("userName", request.getSession(false).getAttribute("userName"));
			// mav.addObject("firstname", loginUsersMaster.getUserName());
		} else {
			mav = new ModelAndView("login");
			mav.addObject("message", "Username or Password is invalid!!");

		}
		return mav;
	}

	@RequestMapping(value = "/showLogoutPage", method = RequestMethod.GET)
	public ModelAndView showLogoutPage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mod = new ModelAndView("login");
		mod.addObject("login", new Login());
		if (request.getSession(false) != null) {
			request.getSession(false).invalidate();
		}
		return mod;
	}

	/*
	 * @RequestMapping(value = "/admin", method = RequestMethod.GET) public String
	 * admin() { return "admin"; }
	 */
}
