package com.lbms.dao;

import java.util.List;
import com.lbms.models.BookMaster;

public interface BookDao {
	public void saveBook(BookMaster bookMaster);
	public List<BookMaster> listBooks();
}
