package com.lbms.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lbms.dao.IssueBookDao;
import com.lbms.models.IssueBookMaster;

@Repository("defaultIssueBookDao")
public class IssueBookDaoImpl implements IssueBookDao {
	private static final Logger logger = LoggerFactory.getLogger(BookDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveIssueBook(IssueBookMaster issueBookMaster) {
		this.sessionFactory.getCurrentSession().save(issueBookMaster);
	}
	
	@SuppressWarnings("unchecked")
	// @Override
	public List<IssueBookMaster> listIssueBooks() {
		Session session = this.sessionFactory.getCurrentSession();
		List<IssueBookMaster> issueBookList = session.createQuery("from IssueBookMaster").list();
		for (IssueBookMaster issueBookMaster : issueBookList)
			logger.info("Person List::" + issueBookMaster);
		return issueBookList;
	}
}
