package com.lbms.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lbms.dao.LoginDao;
import com.lbms.models.BookMaster;
import com.lbms.models.Login;
import com.lbms.models.LoginUsersMaster;

@Repository("defaultLoginDao")
public class LoginDaoImpl implements LoginDao {
	private static final Logger logger = LoggerFactory.getLogger(LoginDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory;

	//@Override
	public void registerLogin(LoginUsersMaster loginUsersMaster) {
		this.sessionFactory.getCurrentSession().save(loginUsersMaster);
	}

	public LoginUsersMaster validateLogin(Login login) {
		Session session = this.sessionFactory.getCurrentSession();
	
		String userName = login.getLoginName();
		String userPass = login.getPassword();
		
		Criteria criteria = session.createCriteria(LoginUsersMaster.class);
		/*
		 * criteria.add(Restrictions.gt("userName", userName));
		 * criteria.add(Restrictions.gt("userPass", userPass));
		 */
		
		criteria.add(Restrictions.eqOrIsNull("userName", userName));
		criteria.add(Restrictions.eqOrIsNull("userPass", userPass));
		
		List<LoginUsersMaster> lstLogin = criteria.list();
		
		return lstLogin.size() > 0 ? lstLogin.get(0) : null;
		//return lstLogin;
	}
}
