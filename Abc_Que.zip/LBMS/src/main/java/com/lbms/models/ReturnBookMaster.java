package com.lbms.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bookreturn_mst")
public class ReturnBookMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_bkRetId")
	private Integer returnBookId;
	//private Integer retIssbookId;
	private String retBookCode;
	@Column(name = "retFk_StuId")
	private Integer retStuId;

	public Integer getReturnBookId() {
		return returnBookId;
	}

	public void setReturnBookId(Integer returnBookId) {
		this.returnBookId = returnBookId;
	}

	/*
	 * public Integer getRetIssbookId() { return retIssbookId; }
	 * 
	 * public void setRetIssbookId(Integer retIssbookId) { this.retIssbookId =
	 * retIssbookId; }
	 */
	public String getRetBookCode() {
		return retBookCode;
	}

	public void setRetBookCode(String retBookCode) {
		this.retBookCode = retBookCode;
	}

	public Integer getRetStuId() {
		return retStuId;
	}

	public void setRetStuId(Integer retStuId) {
		this.retStuId = retStuId;
	}
}
