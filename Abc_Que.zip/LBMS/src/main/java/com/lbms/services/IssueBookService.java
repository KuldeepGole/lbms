package com.lbms.services;

import java.util.List;

import com.lbms.models.IssueBookMaster;

public interface IssueBookService {
	public void saveIssueBook(IssueBookMaster issueBookMaster);
	public List<IssueBookMaster> listIssueBooks();
}
