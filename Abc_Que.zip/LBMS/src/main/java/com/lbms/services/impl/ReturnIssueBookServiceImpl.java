package com.lbms.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lbms.services.ReturnIssueBookService;
import com.lbms.models.ReturnBookMaster;
import com.lbms.dao.ReturnIssueBookDao;

@Service("defaultReturnIssueBookService")
@Transactional
public class ReturnIssueBookServiceImpl implements ReturnIssueBookService {
	@Autowired
	private ReturnIssueBookDao returnIssueBookDao;

	public void saveReturnIssueBook(ReturnBookMaster returnBookMaster) {
		returnIssueBookDao.saveReturnIssueBook(returnBookMaster);
	}
}
