package com.lbms.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@ComponentScan("com.lbms")
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	/*
	 * @Autowired public void configureGlobal(AuthenticationManagerBuilder
	 * authenticationMgr) throws Exception {
	 * authenticationMgr.inMemoryAuthentication().withUser("Librarian_01").password(
	 * "Librarian_01#321").authorities("ROLE_LIBRARIAN"); }
	 */

	@Bean
	public UserDetailsService userDetailsService() {
		InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
		manager.createUser(
				User.withDefaultPasswordEncoder().username("Admin").password("admin@321#").roles("ADMIN").build());
		manager.createUser(
				User.withDefaultPasswordEncoder().username("Librarian_01").password("Librarian_01#321").roles("LIBRARIAN").build());
		return manager;
	}

	@Override
	public void configure(HttpSecurity httpSecurity) throws Exception {
		httpSecurity.authorizeRequests().antMatchers("/librarian").access("hasRole('LIBRARIAN')").and().formLogin()
				.loginPage("/login").defaultSuccessUrl("/librarian").failureUrl("/login?error").usernameParameter("loginName")
				.passwordParameter("passsword").and().logout().logoutSuccessUrl("/login?logout");
	}

	/*
	 * @Bean public UserDetailsService userDetailsService() {
	 * InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
	 * manager.createUser(
	 * User.withDefaultPasswordEncoder().username("Admin").password("admin@321#").
	 * roles("ADMIN").build()); return manager; }
	 */

	/*
	 * @Override protected void configure(HttpSecurity http) throws Exception {
	 * http.authorizeRequests().antMatchers("/index",
	 * "/").permitAll().antMatchers("/admin").authenticated().and()
	 * .formLogin().loginPage("/login").and().logout() .logoutRequestMatcher(new
	 * AntPathRequestMatcher("/logout")); }
	 */
}
