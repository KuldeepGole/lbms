package com.lbms.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lbms.models.Login;
import com.lbms.models.LoginUsersMaster;
import com.lbms.services.LoginService;

@SuppressWarnings("unused")
@Controller
public class LoginController {
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	@Autowired
	private LoginService loginService;

	/*
	 * @RequestMapping(value = "/login", method = RequestMethod.GET) public
	 * ModelAndView showLoginPage(HttpServletRequest request, HttpServletResponse
	 * response) { ModelAndView mod = new ModelAndView("login");
	 * mod.addObject("login", new Login()); return mod; }
	 *
	 *
	 */

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView loginPage(@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout) {

		ModelAndView model = new ModelAndView();
		if (error != null) {
			model.addObject("error", "Invalid Credentials provided.");
		}

		if (logout != null) {
			model.addObject("message", "Logged out successfully.");
		}

		model.setViewName("login");
		return model;
	}

	// LoginProcess action name of login page
	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("login") Login login) {
		ModelAndView mav = null;

		LoginUsersMaster loginUsersMaster = loginService.validateLogin(login);

		if (null != loginUsersMaster) {
			mav = new ModelAndView("librarian");

			// mav.addObject("firstname", loginUsersMaster.getUserName());
		} else {
			mav = new ModelAndView("login");
			mav.addObject("message", "Username or Password is invalid!!");
		}
		return mav;
	}

	/*
	 * @RequestMapping(value = "/admin", method = RequestMethod.GET) public String
	 * admin() { return "admin"; }
	 */
}
