package com.lbms.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lbms.models.ReturnBookMaster;
import com.lbms.services.ReturnIssueBookService;

@Controller
public class ReturnIssueBookMaster {
	@Autowired
	private ReturnIssueBookService returnIssueBookService;

	@RequestMapping(value = "/showReturnBookPage", method = RequestMethod.GET)
	public ModelAndView showReturnIssueBooks(HttpServletRequest request,
			@ModelAttribute("returnBookMaster") ReturnBookMaster returnBookMaster, ModelMap model) {
		return new ModelAndView("librarian/returnbooks", model);
	}

	@RequestMapping(value = "**/saveOrUpdateReturnIssueBooks", method = RequestMethod.POST)
	public ModelAndView showOrUpdateReturnIssueBook(HttpServletRequest request,
			@ModelAttribute("returnBookMaster") ReturnBookMaster returnBookMaster, BindingResult result,
			ModelMap model) {
		if (returnBookMaster.getRetBookCode() == "") {
			model.addAttribute("message", "Book Code is Required!");
			return new ModelAndView("librarian/returnbooks", model);
		} else if (returnBookMaster.getRetStuId() == 0 || returnBookMaster.getRetStuId() == null ) {
			model.addAttribute("message", "Student Id is Required!");
			return new ModelAndView("librarian/returnbooks", model);
		} else {
		returnIssueBookService.saveReturnIssueBook(returnBookMaster);
		model.addAttribute("message", "Recourd saved Successfully");
		return new ModelAndView("librarian/returnbooks", model);
		}
	}
}
