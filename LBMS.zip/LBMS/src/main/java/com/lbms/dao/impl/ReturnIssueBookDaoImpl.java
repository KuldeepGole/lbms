package com.lbms.dao.impl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lbms.dao.ReturnIssueBookDao;
import com.lbms.models.ReturnBookMaster;

@Repository("defautIssueBookDao")
public class ReturnIssueBookDaoImpl implements ReturnIssueBookDao {

	@Autowired
	private SessionFactory sessionFactory; 
		
	public void saveReturnIssueBook(ReturnBookMaster returnBookMaster) {
		this.sessionFactory.getCurrentSession().save(returnBookMaster);
	}
}
