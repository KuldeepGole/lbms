package com.lbms.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "login_users_mst")
public class LoginUsersMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_LogUsrId")
	private Integer loginId;
	@Column(name = "loginName")
	private String userName;
	@Column(name = "loginPwd")
	private String userPass;
	@Column(name = "userFirstName")
	private String firstName;
	@Column(name = "userLastName")
	private String lastName;
	@Column(name = "userContactNo")
	private String contant;
	@Column(name = "userEmail")
	private String email;
	@Column(name = "userActive")
	private int isActive = 1;
	@Column(name = "isPwdChange")
	private int isChange = 0;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContant() {
		return contant;
	}

	public void setContant(String contant) {
		this.contant = contant;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
