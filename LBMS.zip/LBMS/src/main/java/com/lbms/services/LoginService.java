package com.lbms.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lbms.models.Login;
import com.lbms.models.LoginUsersMaster;

@Service
public interface LoginService {

	public void registerLogin(LoginUsersMaster loginUsersMaster);

	public LoginUsersMaster validateLogin(Login login);
}
