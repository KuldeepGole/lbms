package com.lbms.services;

import com.lbms.models.ReturnBookMaster;

public interface ReturnIssueBookService {
	public void saveReturnIssueBook(ReturnBookMaster returnBookMaster);
}
