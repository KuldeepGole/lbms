package com.lbms.dao;

import java.util.List;

import com.lbms.models.IssueBookMaster;

public interface IssueBookDao {
	public void saveIssueBook(IssueBookMaster issueBookMaster);
	public List<IssueBookMaster> listIssueBooks();
}
