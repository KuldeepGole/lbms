package com.lbms.dao;

import java.util.List;

import com.lbms.models.Login;
import com.lbms.models.LoginUsersMaster;

public interface LoginDao {
	public void registerLogin(LoginUsersMaster loginUsersMaster);
	public LoginUsersMaster validateLogin(Login login);
}
