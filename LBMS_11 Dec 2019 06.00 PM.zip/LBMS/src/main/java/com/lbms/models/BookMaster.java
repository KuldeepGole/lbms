package com.lbms.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
//import javax.validation.constraints.Size;

//import org.hibernate.validator.constraints.NotEmpty;  

@Entity
@Table(name = "Book_Mst")
public class BookMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_bookId")
	private Integer bookId;
	
	//@SuppressWarnings("deprecation")
	//@NotEmpty(message = "Please enter the book code.")
	private String bookCode;
	
	//@SuppressWarnings("deprecation")
	//@NotEmpty(message = "Please enter the book name.")
	private String bookName;
	
	//@SuppressWarnings("deprecation")
	//@NotEmpty(message = "Please enter the book author name.")
	private String bookAuther;
	
	//@SuppressWarnings("deprecation")
	//@NotEmpty(message = "Please enter the book publisher name.")
	private String bookPublisher;
	
	//@SuppressWarnings("deprecation")
	//@NotEmpty(message = "Please enter the book quaintity.")
	//@Size(min=1, message="required")
	//@Column(name = "bookQuantity", nullable = false)
	private Integer bookQuantity;

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getBookCode() {
		return bookCode;
	}

	public void setBookCode(String bookCode) {
		this.bookCode = bookCode;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getBookAuther() {
		return bookAuther;
	}

	public void setBookAuther(String bookAuther) {
		this.bookAuther = bookAuther;
	}

	public String getBookPublisher() {
		return bookPublisher;
	}

	public void setBookPublisher(String bookPublisher) {
		this.bookPublisher = bookPublisher;
	}

	public Integer getBookQuantity() {
		return bookQuantity;
	}

	public void setBookQuantity(Integer bookQuantity) {
		this.bookQuantity = bookQuantity;
	}
}
