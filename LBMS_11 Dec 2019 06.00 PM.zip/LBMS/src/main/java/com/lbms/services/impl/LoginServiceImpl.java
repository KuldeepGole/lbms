package com.lbms.services.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lbms.dao.LoginDao;
import com.lbms.models.Login;
import com.lbms.models.LoginUsersMaster;
import com.lbms.services.LoginService;

@Service
public class LoginServiceImpl implements LoginService {
	@Autowired
	public LoginDao loginDao;

	@Transactional
	public void registerLogin(LoginUsersMaster loginUsersMaster) {
		loginDao.registerLogin(loginUsersMaster);
	}

	@Transactional
	public LoginUsersMaster validateLogin(Login login) {
		return loginDao.validateLogin(login);
	}

}
