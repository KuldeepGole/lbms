package com.lbms.admin.models;

import java.util.Date;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

import com.lbms.admin.validator.Phone;

public class LibrarianMaster {
	
	@Size(min=2, max=30)
	private String name;
	
	@NotEmpty @Email	
	private String email;
	
	@NotNull @Min(18) @Max(100)
	private String age;
	
	@NotNull
	private String gender;	
	
	@DateTimeFormat(pattern="MM/dd/yyyy")
    @NotNull @Past
    private Date birthday;
	
	@Phone
    private String phone;
}
