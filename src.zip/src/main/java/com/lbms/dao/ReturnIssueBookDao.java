package com.lbms.dao;

import com.lbms.models.ReturnBookMaster;

public interface ReturnIssueBookDao {
	public void saveReturnIssueBook(ReturnBookMaster returnBookMaster);
}
